import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:flutter/widgets.dart';

class LoginPage extends StatelessWidget {
  const LoginPage({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Login',
      home: Scaffold(
        body: LoginMethod(),
      ),
    );
  }
}

class LoginMethod extends StatelessWidget {
  const LoginMethod({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.start,
      children: <Widget>[
        SizedBox(
          height: 72,
        ),
        Image.asset('images/background1.png'),
        Image.asset('images/logo.png'),
        const Text(
          'Login',
          style: TextStyle(
            decoration: TextDecoration.none,
            fontFamily: 'Lexend',
            fontSize: 32,
            fontWeight: FontWeight.w200,
            color: Colors.black,
          ),
        ),
        const SizedBox(
          height: 32,
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            decoration: InputDecoration(
              prefixIcon: Icon(Icons.person_outline),
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              hintText: 'username or e-mail',
            ),
            style: TextStyle(
              fontFamily: 'Lexend',
              fontSize: 16,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
        ),
        const SizedBox(
          height: 12,
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16),
          child: TextField(
            decoration: InputDecoration(
              prefixIcon: Icon(Icons.lock_open),
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(16)),
              hintText: 'password',
            ),
            style: TextStyle(
              fontFamily: 'Lexend',
              fontSize: 16,
              fontWeight: FontWeight.w400,
              color: Colors.black,
            ),
          ),
        ),
        const SizedBox(
          height: 24,
        ),
        Container(
          //LoginButton
          height: 52,
          width: 329,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(34),
            color: Colors.greenAccent,
          ),
          child: Text(
            'Login',
            style: TextStyle(
                decoration: TextDecoration.none,
                fontFamily: 'Lexend',
                fontSize: 16,
                color: Colors.black,
                fontWeight: FontWeight.w400),
          ),
        ),
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 16),
          child: Text(
            'esqueci minha senha',
            style: TextStyle(
              fontFamily: 'Lexend',
              fontSize: 14,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }
}
